from django.contrib import admin
from .models import Company, Job, Question, Application, Answer


class QuestionInline(admin.StackedInline):
    model = Question
    extra = 1
    fields = ("order", "section", "text", "help_text", "qtype", "choices", "weight", "required")


@admin.register(Company)
class CompanyAdmin(admin.ModelAdmin):
    list_display = ("name", "slug")


@admin.register(Job)
class JobAdmin(admin.ModelAdmin):
    list_display = ("title", "company", "is_open", "slug")
    inlines = [QuestionInline]


class AnswerInline(admin.TabularInline):
    model = Answer
    extra = 0
    readonly_fields = ("question", "value")


@admin.register(Application)
class ApplicationAdmin(admin.ModelAdmin):
    list_display = ("name", "job", "status", "score", "submitted")
    list_filter = ("job", "status")
    search_fields = ("name", "email", "answers__value")
    inlines = [AnswerInline]
