from django.urls import path
from . import views

urlpatterns = [
    path("apply/<slug:slug>/", views.apply, name="apply"),
    path("apply/<slug:slug>/thanks/", views.thanks, name="thanks"),
    path("dashboard/", views.dashboard, name="dashboard"),
    path("dashboard/export.csv", views.export_csv, name="export"),
    path("dashboard/<int:pk>/", views.detail, name="detail"),
    path("dashboard/<int:pk>/resume/", views.resume, name="resume"),
]
