import secrets
from django.db import models
from django.utils.text import slugify


class Company(models.Model):
    name = models.CharField(max_length=150)
    slug = models.SlugField(unique=True, blank=True)

    class Meta:
        verbose_name_plural = "companies"

    def save(self, *a, **kw):
        if not self.slug:
            self.slug = slugify(self.name)
        super().save(*a, **kw)

    def __str__(self):
        return self.name


class Job(models.Model):
    company = models.ForeignKey(Company, on_delete=models.CASCADE, related_name="jobs")
    title = models.CharField(max_length=200)
    slug = models.SlugField(unique=True, blank=True, help_text="Used in the public link: /apply/<slug>/")
    intro = models.TextField(blank=True, help_text="Shown at the top of the form.")
    is_open = models.BooleanField(default=True)
    created = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created"]

    def save(self, *a, **kw):
        if not self.slug:
            base = slugify(f"{self.company.name}-{self.title}")[:45]
            self.slug = f"{base}-{secrets.token_hex(2)}"
        super().save(*a, **kw)

    def __str__(self):
        return f"{self.title} ({self.company})"


class Question(models.Model):
    TEXT, LONG, NUMBER, SINGLE, MULTI = "text", "long", "number", "single", "multi"
    TYPES = [
        (TEXT, "Short text"),
        (LONG, "Long text"),
        (NUMBER, "Number"),
        (SINGLE, "Single choice"),
        (MULTI, "Multiple choice"),
    ]
    job = models.ForeignKey(Job, on_delete=models.CASCADE, related_name="questions")
    section = models.CharField(max_length=100, blank=True, help_text="Groups questions, e.g. 'Availability'")
    text = models.CharField(max_length=500)
    help_text = models.CharField(max_length=300, blank=True)
    qtype = models.CharField("type", max_length=10, choices=TYPES, default=TEXT)
    choices = models.TextField(
        blank=True,
        help_text="One option per line. Optional score after a pipe, e.g.  Yes|10  or  Remote only|2",
    )
    weight = models.PositiveIntegerField(
        default=0, help_text="Max points this question can earn. 0 = not scored."
    )
    required = models.BooleanField(default=True)
    order = models.PositiveIntegerField(default=0)

    class Meta:
        ordering = ["order", "id"]

    def __str__(self):
        return self.text[:80]

    @property
    def options(self):
        """[(label, points)] parsed from the choices field."""
        out = []
        for line in self.choices.splitlines():
            line = line.strip()
            if not line:
                continue
            label, _, pts = line.partition("|")
            try:
                pts = float(pts) if pts.strip() else 0
            except ValueError:
                pts = 0
            out.append((label.strip(), pts))
        return out

    @property
    def is_choice(self):
        return self.qtype in (self.SINGLE, self.MULTI)

    @property
    def is_manual(self):
        """Scored questions that a human must mark (free text)."""
        return self.weight > 0 and not self.is_choice and self.qtype != self.NUMBER

    def auto_points(self, value):
        """Points for a choice answer, scaled to the question weight."""
        if not self.weight or not self.is_choice:
            return None
        pts = dict(self.options)
        chosen = [v for v in value.split(" | ") if v]
        if self.qtype == self.SINGLE:
            best = max(pts.values(), default=0)
            got = pts.get(chosen[0], 0) if chosen else 0
        else:
            best = sum(p for p in pts.values() if p > 0)
            got = sum(pts.get(c, 0) for c in chosen)
        if best <= 0:
            return 0
        return round(max(0, min(got / best, 1)) * self.weight, 2)


class Application(models.Model):
    STATUS = [
        ("new", "New"),
        ("shortlisted", "Shortlisted"),
        ("interview", "Interview"),
        ("trial", "Trial assignment"),
        ("empanelled", "Empanelled"),
        ("rejected", "Rejected"),
    ]
    job = models.ForeignKey(Job, on_delete=models.CASCADE, related_name="applications")
    name = models.CharField(max_length=150)
    email = models.EmailField()
    phone = models.CharField(max_length=30)
    submitted = models.DateTimeField(auto_now_add=True)
    status = models.CharField(max_length=15, choices=STATUS, default="new")
    notes = models.TextField(blank=True)
    score = models.FloatField(default=0, help_text="Percent of scored points earned")
    resume = models.FileField(upload_to="resumes/", blank=True)

    class Meta:
        ordering = ["-submitted"]

    def __str__(self):
        return f"{self.name} - {self.job.title}"

    def recalc(self):
        total = earned = 0
        for a in self.answers.select_related("question"):
            q = a.question
            if not q.weight:
                continue
            total += q.weight
            earned += (a.manual_score if q.is_manual else q.auto_points(a.value)) or 0
        self.score = round(earned / total * 100, 1) if total else 0
        self.save(update_fields=["score"])

    @property
    def pending_review(self):
        return self.answers.filter(
            question__weight__gt=0, manual_score__isnull=True
        ).exclude(question__qtype__in=["single", "multi", "number"]).count()


class Answer(models.Model):
    application = models.ForeignKey(Application, on_delete=models.CASCADE, related_name="answers")
    question = models.ForeignKey(Question, on_delete=models.CASCADE)
    value = models.TextField(blank=True)
    manual_score = models.FloatField(null=True, blank=True)

    class Meta:
        ordering = ["question__order", "question_id"]

    @property
    def points(self):
        q = self.question
        if not q.weight:
            return None
        return self.manual_score if q.is_manual else q.auto_points(self.value)
