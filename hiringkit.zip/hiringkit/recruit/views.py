import csv
from django.contrib.admin.views.decorators import staff_member_required
from django.db.models import Q
from django.http import HttpResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.contrib import messages

from .forms import ApplyForm
from .models import Answer, Application, Job


def apply(request, slug):
    job = get_object_or_404(Job, slug=slug)
    if not job.is_open:
        return render(request, "recruit/closed.html", {"job": job})
    form = ApplyForm(job, request.POST or None, request.FILES or None)
    if request.method == "POST" and form.is_valid():
        if form.cleaned_data["website"]:  # bot
            return redirect("thanks", slug=slug)
        d = form.cleaned_data
        app = Application.objects.create(
            job=job, name=d["name"], email=d["email"], phone=d["phone"],
            resume=d.get("resume") or "",
        )
        for q in form.questions:
            v = d[f"q_{q.id}"]
            v = " | ".join(v) if isinstance(v, list) else str(v)
            Answer.objects.create(application=app, question=q, value=v)
        app.recalc()
        return redirect("thanks", slug=slug)
    return render(request, "recruit/apply.html", {"job": job, "form": form})


def thanks(request, slug):
    return render(request, "recruit/thanks.html", {"job": get_object_or_404(Job, slug=slug)})


def _filtered(request):
    qs = Application.objects.select_related("job", "job__company")
    g = request.GET
    if g.get("job"):
        qs = qs.filter(job_id=g["job"])
    if g.get("status"):
        qs = qs.filter(status=g["status"])
    if g.get("min_score"):
        try:
            qs = qs.filter(score__gte=float(g["min_score"]))
        except ValueError:
            pass
    if g.get("q"):
        t = g["q"]
        qs = qs.filter(
            Q(name__icontains=t) | Q(email__icontains=t) | Q(answers__value__icontains=t)
        ).distinct()
    return qs.order_by("-score" if g.get("sort") == "score" else "-submitted")


@staff_member_required
def dashboard(request):
    ctx = {
        "apps": _filtered(request),
        "jobs": Job.objects.all(),
        "statuses": Application.STATUS,
        "g": request.GET,
        "querystring": request.GET.urlencode(),
    }
    return render(request, "recruit/dashboard.html", ctx)


@staff_member_required
def detail(request, pk):
    app = get_object_or_404(Application.objects.select_related("job"), pk=pk)
    if request.method == "POST":
        app.status = request.POST.get("status", app.status)
        app.notes = request.POST.get("notes", "")
        app.save(update_fields=["status", "notes"])
        for a in app.answers.select_related("question"):
            if a.question.is_manual:
                raw = request.POST.get(f"score_{a.id}", "").strip()
                try:
                    val = min(max(float(raw), 0), a.question.weight) if raw else None
                except ValueError:
                    val = None
                a.manual_score = val
                a.save(update_fields=["manual_score"])
        app.recalc()
        messages.success(request, "Saved.")
        return redirect("detail", pk=pk)
    return render(request, "recruit/detail.html", {
        "app": app, "answers": app.answers.select_related("question"),
        "statuses": Application.STATUS,
    })


@staff_member_required
def export_csv(request):
    apps = list(_filtered(request).prefetch_related("answers__question"))
    questions = {}
    for a in apps:
        for ans in a.answers.all():
            questions.setdefault(ans.question_id, ans.question.text)
    resp = HttpResponse(content_type="text/csv")
    resp["Content-Disposition"] = 'attachment; filename="applications.csv"'
    w = csv.writer(resp)
    w.writerow(["Name", "Email", "Phone", "Job", "Status", "Score %", "Submitted", *questions.values()])
    for a in apps:
        by_q = {x.question_id: x.value for x in a.answers.all()}
        w.writerow([a.name, a.email, a.phone, a.job.title, a.get_status_display(), a.score,
                    a.submitted.strftime("%Y-%m-%d %H:%M"), *[by_q.get(qid, "") for qid in questions]])
    return resp


@staff_member_required
def resume(request, pk):
    from django.http import FileResponse, Http404
    app = get_object_or_404(Application, pk=pk)
    if not app.resume:
        raise Http404
    return FileResponse(app.resume.open("rb"), as_attachment=True)
