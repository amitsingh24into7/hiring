from django import forms
from .models import Question, Application


class ApplyForm(forms.Form):
    name = forms.CharField(label="Full name", max_length=150)
    email = forms.EmailField(label="Email")
    phone = forms.CharField(label="Phone", max_length=30)
    resume = forms.FileField(label="CV (PDF or Word, optional)", required=False)
    website = forms.CharField(required=False, widget=forms.HiddenInput)  # honeypot
    consent = forms.BooleanField(
        label="I confirm my answers are accurate and consent to my data being stored for recruitment.",
        error_messages={"required": "Please confirm to continue."},
    )

    def __init__(self, job, *a, **kw):
        super().__init__(*a, **kw)
        self.job = job
        self.questions = list(job.questions.all())
        for q in self.questions:
            self.fields[f"q_{q.id}"] = self._field_for(q)

    def _field_for(self, q):
        kw = dict(label=q.text, required=q.required, help_text=q.help_text)
        if q.qtype == Question.LONG:
            return forms.CharField(widget=forms.Textarea(attrs={"rows": 4}), **kw)
        if q.qtype == Question.NUMBER:
            return forms.DecimalField(min_value=0, **kw)
        if q.qtype == Question.SINGLE:
            return forms.ChoiceField(
                choices=[(l, l) for l, _ in q.options], widget=forms.RadioSelect, **kw
            )
        if q.qtype == Question.MULTI:
            return forms.MultipleChoiceField(
                choices=[(l, l) for l, _ in q.options], widget=forms.CheckboxSelectMultiple, **kw
            )
        return forms.CharField(max_length=300, **kw)

    def clean_resume(self):
        f = self.cleaned_data.get("resume")
        if f:
            if f.size > 5 * 1024 * 1024:
                raise forms.ValidationError("File must be under 5 MB.")
            if not f.name.lower().endswith((".pdf", ".doc", ".docx")):
                raise forms.ValidationError("Upload a PDF or Word file.")
        return f

    def grouped(self):
        """[(section, [bound fields])] preserving order."""
        groups, index = [], {}
        for q in self.questions:
            key = q.section or "Questions"
            if key not in index:
                index[key] = []
                groups.append((key, index[key]))
            index[key].append(self[f"q_{q.id}"])
        return groups
