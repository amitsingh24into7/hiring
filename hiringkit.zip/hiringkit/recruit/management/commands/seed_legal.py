from django.core.management.base import BaseCommand
from recruit.models import Company, Job, Question

T, L, N, S, M = "text", "long", "number", "single", "multi"

# (section, text, type, choices, weight, required, help)
QUESTIONS = [
 ("Background", "Cities where you can work or appear", T, "", 0, True, "e.g. Mumbai, Thane, Pune"),
 ("Background", "Bar Council and year of enrolment", T, "", 0, True, ""),
 ("Background", "Total years of practice", N, "", 5, True, ""),
 ("Background", "Current status", S, "Independent practitioner|3\nWorking in a firm|3\nIn-house|2\nBetween roles|3", 0, True, ""),
 ("Background", "LinkedIn or profile link", T, "", 0, False, ""),

 ("Practice area", "Your practice areas", M,
  "Civil|1\nCriminal|1\nCorporate / Commercial|1\nContracts|1\nProperty / Real estate|1\nRERA|1\nBanking / Recovery / DRT / SARFAESI|1\nNCLT / IBC|1\nArbitration|1\nFamily|1\nConsumer|1\nLabour / Employment|1\nIP|1\nTax|1\nCyber / IT|1\nOther|0", 10, True,
  "Edit the points to favour the areas you need most."),
 ("Practice area", "Your primary practice area", T, "", 0, True, ""),
 ("Practice area", "Courts, tribunals and forums you regularly appear before", T, "", 0, True, ""),
 ("Practice area", "What can you do independently?", M,
  "Drafting|2\nLegal research|2\nCourt appearances|2\nClient meetings|1\nDue diligence|2\nFilings / registrations|1", 10, True, ""),
 ("Practice area", "Describe one recent matter and your specific role", L, "", 10, True, "3 to 5 lines."),
 ("Practice area", "Have you worked for external clients on a freelance or associate basis?", S, "Yes, regularly|5\nYes, occasionally|3\nNo|0", 5, True, ""),
 ("Practice area", "Languages you can work in", M, "English|1\nHindi|1\nMarathi|1\nGujarati|0\nOther|0", 5, True, ""),

 ("Engagement and fees", "Are you comfortable working per assignment, with no guaranteed monthly volume?", S, "Yes|10\nYes, with conditions|5\nNo|0", 15, True, ""),
 ("Engagement and fees", "Preferred billing model", M, "Hourly|2\nPer task (drafting / appearance)|2\nDaily rate|1\nMonthly retainer|0", 0, True, ""),
 ("Engagement and fees", "Your hourly rate (INR)", N, "", 0, True, ""),
 ("Engagement and fees", "Your rate per court appearance (INR)", N, "", 0, False, ""),
 ("Engagement and fees", "Are your rates negotiable for regular work?", S, "Yes|5\nSomewhat|3\nNo|0", 5, True, ""),
 ("Engagement and fees", "When do you expect payment?", S, "On completion|3\nMonthly|3\nAdvance required|0", 0, True, ""),
 ("Engagement and fees", "Are you open to a paid trial assignment at a fixed fee before regular engagement?", S, "Yes|10\nOnly at my normal rate|5\nNo|0", 10, True, ""),
 ("Engagement and fees", "Are you open to a trial period with no fixed monthly payment, paid only per assignment?", S, "Yes|10\nOnly if paid per assignment|8\nNo|0", 10, True, ""),

 ("Availability", "Average hours per day you can give us", N, "", 5, True, ""),
 ("Availability", "Days and time slots you are normally available", L, "", 0, True, ""),
 ("Availability", "Available on weekends and for short-notice work?", S, "Yes, both|10\nWeekends only|5\nShort notice only|5\nNo|0", 10, True, ""),
 ("Availability", "Usual turnaround for a draft or opinion", S, "Within 24 hours|10\n24 to 48 hours|7\n3 to 5 days|3\nLonger|0", 10, True, ""),
 ("Availability", "Any other commitments or clients that could create a conflict of interest?", L, "", 0, True, "Write 'None' if not applicable."),
 ("Availability", "Notice time needed to start, and planned leave in the next 3 months", T, "", 0, True, ""),

 ("Location and long term", "What are you looking for?", S, "Freelance / per assignment|5\nPart-time|5\nFull-time|2", 0, True, ""),
 ("Location and long term", "Would you be interested if a full-time role opens later?", S, "Yes|3\nMaybe|2\nNo|1", 0, True, ""),
 ("Location and long term", "Can you work physically from Navi Mumbai (Kalamboli) if needed?", S, "Yes, regularly|10\nOccasionally|6\nRemote only|2", 10, True, ""),
 ("Location and long term", "If occasionally, how many days per week or month?", T, "", 0, False, ""),
 ("Location and long term", "Do you have your own laptop, internet and legal research subscription (SCC, Manupatra)?", S, "All of these|5\nLaptop and internet only|3\nNo|0", 5, True, ""),

 ("Scenarios", "A client calls at 6 pm and needs a legal notice by next morning. How do you handle it?", L, "", 10, True, ""),
 ("Scenarios", "You find an error in a draft you have already sent. What do you do?", L, "", 5, True, ""),
 ("Scenarios", "How do you keep client information confidential while working remotely for several firms?", L, "", 5, True, ""),
]


class Command(BaseCommand):
    help = "Create a demo company and the Legal Associate screening questionnaire."

    def handle(self, *args, **opts):
        company, _ = Company.objects.get_or_create(name="Demo Law Firm")
        job, created = Job.objects.get_or_create(
            company=company, title="Legal Associate (Flexible / Per Assignment)",
            defaults={"intro": "We are empanelling 1 to 2 legal associates on a per-assignment basis, "
                               "not as full-time staff. Please answer honestly; it takes about 10 minutes."},
        )
        if created:
            for i, (sec, text, qt, ch, w, req, hlp) in enumerate(QUESTIONS, 1):
                Question.objects.create(job=job, order=i, section=sec, text=text, qtype=qt,
                                        choices=ch, weight=w, required=req, help_text=hlp)
        self.stdout.write(self.style.SUCCESS(f"Ready. Apply link: /apply/{job.slug}/"))
