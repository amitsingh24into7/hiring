from django.contrib.auth.models import User
from django.core.management import call_command
from django.test import TestCase
from .models import Job, Application


class FlowTest(TestCase):
    def setUp(self):
        call_command("seed_legal", verbosity=0)
        self.job = Job.objects.get()
        User.objects.create_superuser("boss", "b@x.com", "pw")

    def _payload(self):
        d = {"name": "Asha Rao", "email": "asha@x.com", "phone": "99999", "consent": "on"}
        for q in self.job.questions.all():
            k = f"q_{q.id}"
            if q.qtype == "number":
                d[k] = "3"
            elif q.qtype == "single":
                d[k] = q.options[0][0]
            elif q.qtype == "multi":
                d[k] = [o[0] for o in q.options[:3]]
            else:
                d[k] = "Sample answer RERA Kalamboli"
        return d

    def test_apply_score_dashboard_csv(self):
        r = self.client.get(f"/apply/{self.job.slug}/")
        self.assertContains(r, "Legal Associate")
        r = self.client.post(f"/apply/{self.job.slug}/", self._payload())
        self.assertEqual(r.status_code, 302, getattr(r, "context", None) and r.context["form"].errors)
        app = Application.objects.get()
        self.assertGreater(app.score, 0)
        self.assertEqual(app.pending_review, 4)

        # dashboard is staff only
        self.assertEqual(self.client.get("/dashboard/").status_code, 302)
        self.client.login(username="boss", password="pw")
        self.assertContains(self.client.get("/dashboard/?q=Kalamboli"), "Asha Rao")
        self.assertNotContains(self.client.get("/dashboard/?min_score=100"), "Asha Rao")

        # manual marking raises the score
        before = app.score
        post = {"status": "shortlisted", "notes": "good"}
        for a in app.answers.all():
            if a.question.is_manual:
                post[f"score_{a.id}"] = str(a.question.weight)
        self.client.post(f"/dashboard/{app.id}/", post)
        app.refresh_from_db()
        self.assertGreater(app.score, before)
        self.assertEqual(app.status, "shortlisted")
        self.assertEqual(app.pending_review, 0)

        r = self.client.get("/dashboard/export.csv")
        self.assertIn("Asha Rao", r.content.decode())

    def test_required_validation(self):
        r = self.client.post(f"/apply/{self.job.slug}/", {"name": "x"})
        self.assertEqual(r.status_code, 200)
        self.assertEqual(Application.objects.count(), 0)
